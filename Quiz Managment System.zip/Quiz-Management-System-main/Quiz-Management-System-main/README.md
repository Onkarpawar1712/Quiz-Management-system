# Quiz-Management-System
Quiz Management System using Java and MySQL.Here I deployed my project for running anywhere use QUizapp.jar and QUizapp.bat .Click on QUizapp.bat to run Application.

Output:

1. Welcome Page

![Screenshot 2023-01-25 183701](https://user-images.githubusercontent.com/100481110/214571767-019644f0-2f1d-4d49-90eb-1b199424ab98.png)

2.Student Login Page

![stu_login](https://user-images.githubusercontent.com/100481110/214571830-47a32d44-9fea-48ef-b8c9-46deab829f1c.png)

3.Student Instruction Page

![Screenshot 2023-01-25 183854](https://user-images.githubusercontent.com/100481110/214571891-38127b4d-ef49-4016-b47d-336e0feb9944.png)

4.Student Exam Page

![stu_exampage](https://user-images.githubusercontent.com/100481110/214571914-0ac9518a-2067-4079-9cb9-0793e23b1add.png)

5.Admin Login Page 

![adm_login](https://user-images.githubusercontent.com/100481110/214571940-fdbb9006-682a-4066-9d90-25b81a480d0a.png)

6.Admin Home page

![adm_page](https://user-images.githubusercontent.com/100481110/214571972-3a52388f-0eb8-418a-936a-133e91a8998e.png)

7.Teacher Login Page

![teach_login](https://user-images.githubusercontent.com/100481110/214572000-24bfd8d4-6aec-43ef-a4d0-89ed6cde0214.png)

8.Teacher Home Page

![teach_page](https://user-images.githubusercontent.com/100481110/214572045-843abe8b-7d56-479d-9848-0133bc5a44e7.png)
